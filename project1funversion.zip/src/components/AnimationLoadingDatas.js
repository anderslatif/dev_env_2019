import React, { Component } from 'react'

const AnimationLoadingDatas = () => {
    return (
      <div className="animationLoadingDatas" style={{width:"4.5rem", height:"4.5rem", backgroundColor:"white"}}>
        
      </div>
    )
  }

export default AnimationLoadingDatas;